import { Injectable } from '@nestjs/common';

@Injectable()
export class AppService {
  getHello(): string {
    return 'Hello World!';
  }
  handleEvent(event: any): void {
    console.log('App Service: handleEvent ');
    console.log(event);
  }
}
